import './share.js';
import './popper.min.js';
import './bootstrap.min.js';
import './moment.min.js';
import './bootstrap-datetimepicker.min.js';
import './slick.min.js';
import './select2.min.js';
import './jquery-ui.js';
import './simple-lightbox.js';


// require('./share');
// require('./popper');
// require('./bootstrap');
// require('./moment.min.js');
// require('./bootstrap-datetimepicker');
// require('./slick');
// require('./select2');
// require('./jquery-ui');
// require('./simple-lightbox');


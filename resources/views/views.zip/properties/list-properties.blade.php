@extends('admin-layouts.app')
@section('content')
<div class="content-inner">
    <div class="bc-box">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="float-left mt-2">
                    <div class="d-inline-flex align-items-center">
                        <h1>Properties</h1><span class="font-size-16 font-wt-600 color-gray count"></span>
                        <ol class="bclink">
                            <li class="breadcrumb-item">
                                 <a href="{{ route('admin') }}"><i class="bx bx-home-alt font-size-18 color-gold"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">All Listing</li>
                        </ol>
                    </div>
                </div>
                <!--<div class="float-right">
                    <a href="#" class="btn btn-medium btn-gold ml-2 mr-2 float-right">Add Property</a>
                </div>-->
            </div>
        </div>
    </div>
     <section class="commonbox center" style="display:none" id="norecord">
        <div class="panel-body">
            <i class="material-icons color-pink icon-7x">maps_home_work</i><br><br>
            <h3 class="font-size-18 font-wt-600">No properties available.</h3><br>
        </div>
    </section>
    <div class="row" id="listingsection">
        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="table-responsive animate__animated animate__fadeIn animate__slow">
                <table width="100%" cellspacing="0" cellpadding="0" class="table table-normal" id="list">
                    <thead>
                        <tr>
                            <th width="10%">Image</th>
                            <th>Property</th>
                            <th width="15%">Action</th>
                        </tr>
                    </thead>
                     <tbody>
                     
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<script type="text/javascript">

$.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
$( document ).ready(function() {
var table = $('#list').DataTable({ 
    //"dom": 'Bfrtip',
    "processing": true, //Feature control the processing indicator.
    "serverSide": true,
    //"ordering": true, //Feature control DataTables' server-side processing mode.
    "order": [], //Initial no order.
    // Load data for the table's content from an Ajax source
    "ajax": {
        "url": "{{route('propertylist')}}",
        "type": "POST",
        "data": function ( data ) {
    
        }
    },

    mark: true,
    //dom: 'Bfrtip',
    "lengthMenu": [
        [10, 25, 50, 100, -1],['10 rows', '25 rows', '50 rows', '100 rows', 'Show All']
    ],
    
    //Set column definition initialisation properties.
   "columnDefs": [
    { 
        "targets": [1], //first column / numbering column
        "orderable": false, 
       
    },
    ],

});
$('#btn-filter').click(function(){ //button filter event click
    table.ajax.reload();  //just reload table
});
table.on('draw', function (data) {
    $rocorddisplay=table.page.info().recordsDisplay;
    $totalcount=table.page.info().recordsTotal;
    if($totalcount)
    {
     $('.count').text($totalcount+' Total');
     $('#norecord').css('display','none');
     $('#listingsection').css('display','block');
    }else{
        $('#norecord').css('display','block');
        $('#listingsection').css('display','none');
    }
});
/* table.on( 'draw', function () {

} );*/


});
</script>
@endsection()
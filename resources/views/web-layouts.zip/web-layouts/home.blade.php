@extends('web-layouts.app')
@section('content')
@if($Data->Banners->first())
<section id="main-slider" class="no-margin">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            @php $i=1; @endphp
            @foreach($Data->Banners as $val)
           <div class="carousel-item @if($i==1) active @endif">

               <img class="d-block w-100" src="{{ URL::asset('uploads/banner/'.$val->Image) }}" alt="First slide">
           </div>
             @php $i++; @endphp
             @endforeach
        </div>
        {{-- <button class="carousel-control-prev d-none d-sm-block" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next d-none d-sm-block" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button> --}}
    </div>
</section>
@endif
<div class="animate__animated animate__fadeIn animate__slow">
    <div class="container">


        <div class="searchbox">
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pills-sale-tab" data-bs-toggle="pill" data-bs-target="#pills-sale" type="button" role="tab" aria-controls="pills-sale" aria-selected="true">{{ __('msg.Sale') }}</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="pills-rent-tab" data-bs-toggle="pill" data-bs-target="#pills-rent" type="button" role="tab" aria-controls="pills-rent" aria-selected="false">{{ __('msg.Rent') }}</button>
                </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
                <div class="tab-pane fade show active" id="pills-sale" role="tabpanel" aria-labelledby="pills-sale-tab">
                    <form action="{{ route('search-properties',app()->getLocale()) }}" method="get">
                    <div class="row g-3">
                        <div class="col-xl-3 col-lg-2 col-md-6 col-sm-6 col-12">
                            <div class="form-floating">
                                <select name="t" class="form-select" aria-label="Floating label select example">
                                    <option value="">{{  __('msg.Select') }}</option>
                                    @foreach($Data->PropertyUnitTypes as $unitypes)
                                    <option value="{{ $unitypes->ID }}">{{ $unitypes->TypeName }}</option>
                                    @endforeach
                                </select>
                                <label>{{  __('msg.PropertyType') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                            <div class="form-floating">
                                <select name="c" class="form-select select2 city" aria-label="Floating label select example">
                                    <option value="">{{  __('msg.Select') }}</option>
                                    @foreach($Data->City as $city)
                                    <option value="{{ $city->ID }}">{{ $city->CityName }}</option>
                                    @endforeach
                                </select>
                                <label >{{  __('msg.City') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-5 col-md-6 col-sm-6 col-12">
                            <div class="form-floating">
                                <select name="l[]" class="form-select select2 locationlist" multiple="multiple"  aria-label="Floating label select example">
                                </select>
                                <label>{{  __('msg.SelectMultipleLocations') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <input type="text"  name="rfn" class="form-control" placeholder="">
                                <label>{{  __('msg.ReferenceNo') }}</label>
                                <input type="hidden"  name="adt" value="Sale">
                                <input type="hidden"  name="ly" value="1">
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select name="mnpr" class="form-select" aria-label="Floating label select example">
                                    <option value="" selected>{{  __('msg.Select') }}</option>
                                    <option value="0">{{ currency_format(0)  }}</option> 
                                    @foreach (config('constants.MinPrice') as $key=>$minprice)
                                    <option value="{{ $key }}">{{ currency_format($key)  }}</option> 
                                    @endforeach
                                </select>
                                <label>{{  __('msg.MinPrice') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select name="mxpr" class="form-select" aria-label="Floating label select example">
                                    <option value="" selected>{{  __('msg.Select') }}</option>
                                    @foreach (config('constants.MaxPrice') as $key=>$maxprice)
                                    <option value="{{ $key }}">{{ currency_format($key)  }}@if($key==100000000)++@endif</option> 
                                    @endforeach
                                </select>
                                <label>{{  __('msg.MaxPrice') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select name="mnbd"  class="form-select" aria-label="Floating label select example">
                                    <option value='' selected>{{  __('msg.Select') }}</option>
                                    @foreach (config('constants.BedRooms') as $key=>$beds)
                                    <option value="{{ $key }}" {{ (app('request')->input('mnbd') == $key)? "selected": "" }}>{{ $beds  }}</option> 
                                    @endforeach
                                </select>
                                <label >{{  __('msg.MinBed') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select   name="mxbd" class="form-select" aria-label="Floating label select example">
                                    <option value="" selected>{{  __('msg.Select') }}</option>
                                    @foreach (config('constants.BedRooms') as $key=>$beds)
                                    <option value="{{ $key }}" {{ (app('request')->input('mxbd') == $key)? "selected": "" }}>{{ $beds  }}</option> 
                                    @endforeach
                                </select>
                                <label>{{  __('msg.MaxBed') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-4 col-md-4 col-sm-4 col-12">
                            <button class="btn btn-large w-100 btn-gold btn-block" type="submit">{{  __('msg.Search') }}</button>
                        </div>
                    </div>
                    </form>
                </div>
                <div class="tab-pane fade" id="pills-rent" role="tabpanel" aria-labelledby="pills-rent-tab">
                    <form action="{{ route('search-properties',app()->getLocale()) }}" method="get">
                    <div class="row g-3">
                        <div class="col-xl-3 col-lg-2 col-md-6 col-sm-6 col-12">
                            <div class="form-floating">
                                <select name="t" class="form-select" aria-label="Floating label select example">
                                    <option value="">{{  __('msg.Select') }}</option>
                                    @foreach($Data->PropertyUnitTypes as $unitypes)
                                    <option value="{{ $unitypes->ID }}">{{ $unitypes->TypeName }}</option>
                                    @endforeach
                                </select>
                                <label>{{  __('msg.PropertyType') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-12">
                            <div class="form-floating">
                                <select name="c" class="form-select select2 city" aria-label="Floating label select example">
                                    <option value="">{{  __('msg.Select') }}</option>
                                    @foreach($Data->City as $city)
                                    <option value="{{ $city->ID }}">{{ $city->CityName }}</option>
                                    @endforeach
                                </select>
                                <label >{{  __('msg.City') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-6 col-lg-5 col-md-6 col-sm-6 col-12">
                            <div class="form-floating">
                                <select name="l[]" class="form-select select2 locationlist" multiple="multiple"  aria-label="Floating label select example">
                                    
                                </select>
                                <label>Select Multiple Location</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <input type="text"  name="rfn" class="form-control"   placeholder="">
                                <label>{{  __('msg.ReferenceNo') }}</label>
                                <input type="hidden"  name="adt" value="Rent">
                                <input type="hidden"  name="ly" value="1">
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select name="mnpr" class="form-select" aria-label="Floating label select example">
                                    <option value="" selected>{{  __('msg.Select') }}</option>
                                    <option value="0">{{ currency_format(0)  }}</option> 
                                    @foreach (config('constants.MinPriceRent') as $key=>$minprice)
                                    <option value="{{ $key }}">{{ currency_format($key)  }}</option> 
                                    @endforeach
                                </select>
                                <label>{{  __('msg.MinPrice') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select name="mxpr" class="form-select" aria-label="Floating label select example">
                                    <option value="" selected>{{  __('msg.Select') }}</option>
                                    @foreach (config('constants.MaxPriceRent') as $key=>$maxprice)
                                    <option value="{{ $key }}">{{ currency_format($key)  }}@if($key==2000000)++@endif</option> 
                                    @endforeach
                                </select>
                                <label>{{  __('msg.MaxPrice') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select name="mnbd"  class="form-select" aria-label="Floating label select example">
                                    <option value='' selected>{{  __('msg.Select') }}</option>
                                    @foreach (config('constants.BedRooms') as $key=>$beds)
                                    <option value="{{ $key }}" {{ (app('request')->input('mnbd') == $key)? "selected": "" }}>{{ $beds  }}</option> 
                                    @endforeach
                                </select>
                                <label >{{  __('msg.MinBed') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6 col-6">
                            <div class="form-floating">
                                <select   name="mxbd" class="form-select" aria-label="Floating label select example">
                                    <option value="" selected>{{  __('msg.Select') }}</option>
                                    @foreach (config('constants.BedRooms') as $key=>$beds)
                                    <option value="{{ $key }}" {{ (app('request')->input('mxbd') == $key)? "selected": "" }}>{{ $beds  }}</option> 
                                    @endforeach
                                </select>
                                <label>{{  __('msg.MaxBed') }}</label>
                            </div>
                        </div>
                        <div class="col-xl-2 col-lg-4 col-md-4 col-sm-4 col-12">
                            <button class="btn btn-large w-100 btn-gold btn-block" type="submit">{{  __('msg.Search') }}</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="gray pt-5 pb-5 d-none d-sm-block"  style="background: #fff url('images/back8.png') no-repeat scroll center center;background-size:100%;background-origin: content-box;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 center">
                <h1 class="font-size-40 font-wt-700 pull-left animate__animated animate__fadeIn animate__slow">{{ __('msg.headline') }}</h1>
            </div>
        </div>
        <br /><br /><br />
        <div class="row" dir="ltr">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-12">
            </div>
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-12 mb-3 animate__animated animate__slideInLeft animate__slow">
                <img src="images/slide2.jpg" width="90%" style="border-radius:10px;" />
            </div>
            <div class="col-xl-5 col-lg-5 col-md-5 col-sm-5 col-12 mb-3">
                <br /><br />
                {!! __('msg.welcome') !!}
                <a href="{{ route('about-us',app()->getLocale()) }}" class="btn btn-large btn-gold animate__animated animate__fadeIn animate__slow"> {{ __('msg.AboutUs') }}</a>
            </div>
        </div>
    </div>
    <br /><br /><br /><br /><br />
</section>
@if(count($Data->Feautured) > 0)
<section class="gray">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h1 class="font-size-28 font-wt-600 animate__animated animate__fadeIn animate__slow">{{  __('msg.FeaturedProperties') }}</h1>
                <p class="font-size-16 color-black animate__animated animate__fadeIn animate__slow">{{  __('msg.FeaturedText') }}</p>
            </div>
        </div><br />
        <div class="row">
            @foreach ($Data->Feautured as $val)
            @php $PropertyLinkTitle=trim(str_replace(' ', '-', $val->PropertyLinkTitle)); @endphp
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12" >
                <div class="card animate__animated animate__fadeIn animate__slow">
                    <figure>
                        <a href="{{ route('property-details',[app()->getLocale(),'sale',$PropertyLinkTitle,$val->Guid]) }}">
                            @if ($val->FileName)
                                <img src="{{ asset("uploads/properties/orignal/".$val->PropertyRefNo."/".$val->FileName) }}" class="card-img-top listing-card-img" alt="{{ $val->ImgAlt }}">
                                <div class="list-overlay"></div>  
                            @else
                                <img src="{{ asset("images/noimg.jpg")}}" class="card-img-top listing-card-img" alt="no image">
                                <div class="list-overlay"></div>  
                                
                            @endif
                            </a>
                        <p class="location color-white"><i class="material-icons icon-1x">location_on</i>{{ $val->CommunityName }}, {{ $val->CityName }}, {{  __('msg.Jordan') }}</p>
                    </figure>
                    <div class="card-body">
                        <a href="{{ route('property-details',[app()->getLocale(),'sale',$PropertyLinkTitle,$val->Guid]) }}">
                            <h1 class="font-size-16 font-wt-600">{{ Str::limit(trim(preg_replace('/\s\s+/', ' ', $val->PropertyTitle)),70, $end='...')}}</h1>
                        </a>
                        <p class="font-size-16 font-wt-700 color-gold ">{{  currency_format($val->Price) }}</p>
                        <div class="clearfix"></div>
                        <p class="font-size-12 font-wt-500 color-gray">{!! Str::limit(strip_tags($val->Description),100, $end='.......')  !!}</p>
                        <div class="row ps-2 pe-2">
                            <div class="col-xl-8 col-lg-12 col-md-8 col-sm-8 col-8 ps-0 pe-0 pt-1 pb-1">
                                <i class="material-icons icon-3x color-gray">king_bed</i>
                                <span class="font-wt-500">{{ $val->NoBedrooms }}</span>
                                @if($val->NoBathrooms)
                                <i class="material-icons icon-3x color-gray ps-2">shower</i>
                                <span class="font-wt-500">{{ $val->NoBathrooms }}</span>
                                @endif

                                @if($val->UnitBuiltupArea)
                                            <i class="material-icons color-gray ps-2">aspect_ratio</i>
                                            <span class="font-wt-500">{{ $val->UnitBuiltupArea }} Sqm.</span>
                                            @elseif($val->UnitBuiltupArea && $val->PlotSize)
                                            <i class="material-icons color-gray ps-2">aspect_ratio</i>
                                             <span class="font-wt-500">{{ $val->UnitBuiltupArea }} Sqm.</span>
                                            @elseif($val->PlotSize)
                                            <i class="material-icons color-gray ps-2">aspect_ratio</i>
                                            <span class="font-wt-500">{{ $val->PlotSize+0 }} Sqm.</span>
                                            @else
                                            @endif
                            </div>
                            <div class="col-xl-4 col-lg-12 col-md-4 col-sm-4 col-4 ps-0 pe-0 pt-1 pb-1">
                                <a href="javascript:void(0)" data-no="{{ $val->PropertyRefNo }}" class="font-size-14 font-wt-500 float-end compare"><i class="material-icons">compare_arrows</i> {{  __('msg.Compare') }}</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            
        </div>
    </div>
</section>
@endif
@if(count($Data->Agents) > 0)
<section style="background:url({{ asset('images/building.jpg') }}) no-repeat scroll center center;background-size:cover; background-attachment:fixed;">
    <br /><br /><br />
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h2 class="font-size-28 font-wt-600 color-white animate__animated animate__fadeIn animate__slow">{{  __('msg.ConsultOurAgents') }}</h2>
               
            </div>
        </div><br />
        <div class="row">

            @foreach ($Data->Agents as $val)
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                <a href="#">
                    <div class="card center h-100 animate__animated animate__fadeIn animate__slow">
                        <div class="card-body">
                            <img src="{{ ($val->DisplayPhoto)? URL::asset('uploads/agent/'.$val->DisplayPhoto)  :  asset('images/default_agent_image.png')}}" class="img-round-border" alt="">
                            <br /><br />
                            <h1 class="font-size-16 font-wt-600">{{ ($val->DisplayName)? $val->DisplayName : "-"}}</h1>
                            <p class="font-wt-500 color-gold">{{ ($val->DisplayEmail)? $val->DisplayEmail : "-"}}</p>
                            <p class="font-wt-500">{{ ($val->DisplayPhone)?$val->DisplayPhone: "-" }}</p>
                            <h4><span class="badge rounded-pill gold">{{ ($val->PropertyTypeName)?$val->PropertyTypeName: "-" }}</span></h4>
                        </div>
                    </div>
                </a>
            </div>
            @endforeach
        </div>
    </div>
    <br /><br /><br />
</section>
@endif
@if(count($Data->Testimonials) > 0)
<section class="gold-lt">
    <br /><br /><br />
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h2 class="font-size-28 font-wt-600 animate__animated animate__fadeIn animate__slow">{{  __('msg.WhatClientsSay') }}</h2>
            </div>
        </div><br />
        <div class="row items" dir="ltr">
            @foreach ($Data->Testimonials as $val)
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                <div class="card">
                    <div class="card-body">
                        <i class="material-icons icon-8x color-gold">format_quote</i>
                        <p>{{$val->Message  }}</p>
                        <hr>
                        <div class="row">
                            <!--<div class="col-xl-2 col-lg-3 col-md-3 col-sm-3 col-3">
                                <img src="{{ URL::asset('uploads/testimonial/'.$val->Photo) }}" class="roundborder-lg" alt="">
                            </div>-->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <h1 class="font-size-16 font-wt-600">{{$val->CustomerName  }}</h1>
                               <!-- <p class="color-gray">{{$val->Designation  }}</p>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
          
        </div>
    </div>
    <br /><br /><br />
</section>
@endif
@if(count($Data->Blogs) > 0)
<section class="white">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h2 class="font-size-28 font-wt-600 animate__animated animate__fadeIn animate__slow">{{  __('msg.OurBlogs') }}</h2>
               
            </div>
        </div><br />
        <div class="row">
            @foreach ($Data->Blogs as $val)
            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
                <div class="card animate__animated animate__fadeIn animate__slow">
                    <figure>
                
                        <a href="{{route('blogdetails',[app()->getLocale(),$val->Guid])}}">
                            <img src="{{ URL::asset('uploads/blog/'.$val->Image) }}" class="card-img-top listing-card-img" alt="">
                            <div class="list-overlay"></div>
                        </a>
                    </figure>
                    <div class="card-body">
                        <a href="{{route('blogdetails',[app()->getLocale(),$val->Guid])}}">
                            <h1 class="font-size-16 font-wt-600">{!! Str::limit(strip_tags($val->Title),100, $end='.......')  !!}</h1>
                        </a>
                        <p class="font-size-12 font-wt-500 color-gray">{!! Str::limit(strip_tags($val->Description),100, $end='.......')  !!}</p>
                        <p class="font-size-14 font-wt-500 color-gold  mb-1">{{ date("d-M-Y h:i a",strtotime($val->CreatedDate));  }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
        <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                    <a href="{{ route('blogs',app()->getLocale()) }}" class="btn btn-gold btn-medium">{{  __('msg.AllBlogs') }}</a>
                </div>
            </div>
    </div>
</section>
@endif
@endsection()
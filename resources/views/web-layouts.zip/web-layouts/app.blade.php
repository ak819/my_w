<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Welcome to Home Jordan @yield('title')</title>
    <!--<link href="../css/bootstrap.css" rel="stylesheet">-->
   <!--  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous"> -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!--External Fonts Start-->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" rel="stylesheet" />
    <!--External Fonts End-->
    @if(app()->getLocale()=='en')
    <link href="{{asset('css/mainfront.css')}}" rel="stylesheet">
    @else
    <link href="{{asset('css/mainfrontar.css')}}" rel="stylesheet">
    @endif
    <link href="{{asset('css/boxicons.min.css')}}" rel="stylesheet">
    <link href="{{asset('css/bootstrap-datetimepicker.min.css')}}" rel="stylesheet">
    <link href="{{asset('css/jquery-ui.css')}}" rel="stylesheet">
    <link href="{{asset('css/slick.css')}}" rel="stylesheet" />
    <link href="{{asset('css/slick-theme.css')}}" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.11.0.min.js" type="text/javascript"></script>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>
<body onbeforeunload="handleBackFunctionality()">
    <div class="topbar d-none1 d-sm-block1">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="float-start">
                    </div>
                    <div class="float-end">
                        <div class="float-start">
                            <div class="dropdown d-inline">
                                @php $currency = Session::get('currency'); @endphp 
                                <a class="btn btn-outline-gold" href="javascript:void(0)" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false"><img src="{{ asset("uploads/currency/".$currency[2]) }}" width="30px" alt="" /> {{ $currency[0] }}</a>
                                <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                    @php
                                    $currencies=App\Models\Currency::where('IsEnable',1)->get();
                                   @endphp
                                        @foreach ($currencies as $item)
                                        <li><a class="dropdown-item" href="{{ route('change-currency',$item->Name) }}"><img src="{{asset("uploads/currency/".$item->flag)}}" width="30px" alt="" />&nbsp;&nbsp;&nbsp;{{ $item->Name }}</a></li>
                                       @endforeach 
                                </ul>
                            </div>
                            @if (app()->getLocale() == "ar")
                            <a href="{{ route('changelang','en') }}" class="btn btn-outline-gold me-2">English</a>
                            @else
                            <a href="{{ route('changelang','ar') }}" class="btn btn-outline-gold me-2">عربي</a>
                            @endif
                            
                            <!--<span class="float-left mr-3"><i class="material-icons icon-1x">location_on</i>&nbsp;&nbsp;Building No. 7, King Abdallah Ben Al Hussein Ath Thani St</span>-->
                        </div>
                        <div class="float-end d-none d-sm-block">
                            @php
                            if(app()->getLocale() == "ar")
                            {
                                $contactinfo=App\Models\ContactInfo::first(['Email','Phone','AddressAr AS Address']);
                            }else{
                                $contactinfo=App\Models\ContactInfo::first(['Email','Phone','Address']);
                            }
                            @endphp
                            <a href="tel:{{ $contactinfo->Phone  }}"><span class="d-inline" dir="ltr"><i class="material-icons icon-1x">call</i>&nbsp;&nbsp;{{ $contactinfo->Phone  }}</span>&nbsp;&nbsp;</a>
                            <ul class="float-end">
                                <li class="widget-container social_sidebar">
                                    <div class="social_sidebar_internal">
                                        <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                        <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                                        <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                                        <a href="https://wa.me/{{ $contactinfo->Phone  }}?text=Hello Homes! I would like to enquire about your services." target="_blank"><i class="fab fa-whatsapp"></i></a>
                                        
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<nav class="navbar navbar-expand-lg pt-0 pb-0 white" dir="ltr">
    <div class="container-fluid animate__animated animate__fadeIn animate__slow">
        <span>
             <a href="{{ route('home') }}">
                <img src="{{asset('images/logo.png')}}" alt="logo" class="logo">
            </a>
        </span>
        <button class="navbar-toggler btn btn-outline-gold btn-small" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <i class="material-icons">
                    more_vert
                </i>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
            
                <li class="nav-item">
                    <a class="nav-link" href="{{ url(app()->getLocale().'/search-properties') . '?' . http_build_query(['adt' => 'Sale']); }}">{{ __('msg.Sale') }}</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="{{ url(app()->getLocale().'/search-properties') . '?' . http_build_query(['adt' => 'Rent']); }}">{{ __('msg.Rent') }}</a>
                </li>
              
                 <li class="nav-item dropdown">

                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            {{ __('msg.Services') }}
                        </a>

                        <ul class="dropdown-menu fade-down">
                            @php
                                $services= App\Models\Services::where('IsEnable',1)->get(['Title','TitleAr','Guid']);
                            @endphp
                            @foreach ($services as $item)
                            @if(app()->getLocale()=="en")
                            <li><a class="dropdown-item" href="{{  route('servicesdetails',[app()->getLocale(),$item->Guid]) }}">{{$item->Title}}</a></li>
                            @else
                            <li><a class="dropdown-item" href="{{  route('servicesdetails',[app()->getLocale(),$item->Guid]) }}">{{$item->TitleAr}}</a></li>
                            @endif
                            @endforeach
                        </ul>
                    </li>
               
                <li class="nav-item">
                    <a class="nav-link" href="{{ route('contact-us',app()->getLocale()) }}"> {{ __('msg.Contact') }}</a>
                </li>
                <li class="nav-item center">
                    <a class="btn btn-medium btn-gold" href="{{ route('addproperty',app()->getLocale()) }}">{{ __('msg.ListYourProperty') }}</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
@yield('content')
<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12 pt-4">
                <p class="font-size-18 font-wt-600 color-gold">{{ __('msg.ContactUs') }}</p>
                <p><i class="material-icons icon-1x">location_on</i>&nbsp;{{ $contactinfo->Address  }}</p>
                <p><a  href="tel:{{ $contactinfo->Phone  }}"><i class="material-icons icon-1x">call</i>&nbsp;<span class="ltr">{{ $contactinfo->Phone  }}</span></a></p>
                <a href="mailto:{{ $contactinfo->Email  }}"><p><i class="material-icons icon-1x">email</i>&nbsp;{{ $contactinfo->Email  }}</p></a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12 pt-4">
                <p class="font-size-18 font-wt-600 color-gold">{{ __('msg.Properties') }}</p>
                <ul class="arrow">
                    <li>
                        <a href="{{ url(app()->getLocale().'/search-properties') . '?' . http_build_query(['adt' => 'Sale']); }}">{{ __('msg.ForSale') }}</a>
                    </li>
                    <li>
                        <a href="{{ url(app()->getLocale().'/search-properties') . '?' . http_build_query(['adt' => 'Rent']); }}">{{ __('msg.ForRent') }}</a>
                    </li>
                    <li>
                        <a href="{{ route('addproperty',app()->getLocale()) }}">{{ __('msg.ListYourProperty') }}</a>
                    </li>
                    
                </ul>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12 pt-4">
                <p class="font-size-18 font-wt-600 color-gold">{{ __('msg.QuickLinks') }}</p>
                <ul class="arrow">
                    <li>
                        <a href="{{ route('about-us',app()->getLocale()) }}">{{ __('msg.AboutUs') }}</a>
                    </li>
                    {{-- <li>
                        <a href="#">{{ __('msg.OurServices') }}</a>
                    </li> --}}
                    <li>
                        <a href="{{ route('blogs',app()->getLocale()) }}">{{ __('msg.Blog') }}</a>
                    </li>
                    <li>
                        <a href="#">{{ __('msg.TermsAndConditions') }}</a>
                    </li>
                    <li>
                        <a href="#">{{ __('msg.PrivacyPolicy') }}</a>
                    </li>
                </ul>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-12 pt-4">
                <p class="font-size-18 font-wt-600 color-gold">{{ __('msg.AboutUs') }}</p>
                <p>{{ __('msg.FooterAboutUs') }}</p>
                <a class="btn-social-small btn-facebook" style="color:#fff;" href="#"><i class="fab fa-facebook-f"></i></a>&nbsp;
                <a class="btn-social-small btn-twitter" style="color:#fff;" href="#"><i class="fab fa-twitter"></i></a>&nbsp;
                <a class="btn-social-small btn-instagram" style="color:#fff;" href="#"><i class="fab fa-instagram"></i></a>&nbsp;
                <a class="btn-social-small btn-whatsapp" href="https://wa.me/{{ $contactinfo->Phone  }}?text=Hello Homes! I would like to enquire about your services." href="#"><i class="fab fa-whatsapp"></i></a>

            </div>
        </div>
    </div>
    <br /><br />
    <div>
        <p class="center">© {{ date('Y') }} {{ __('msg.CopyRights') }}</p>
    </div>
</footer>
<div id="compare" class="white" style="background-color:#ffffff; border-top: 4px solid #ac8952; z-index:99; bottom: 0;position: fixed;width: 100%; display:none;">
    <div class="container-fluid">
        <div class="row mt-3">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <span class="font-size-18 font-wt-600 float-start">{{ __('msg.CompareProperties') }}</span>
               
                <div class="float-end">
                    <a href="javascript:void(0)" id="reset-compare" class="btn btn-outline-gold1">{{ __('msg.Reset') }}</a>
                    <a href="{{ route('compare',app()->getLocale()) }}" class="btn btn-gold">{{ __('msg.StartCompare') }}</a>
                </div>               
            </div>
        </div>
        <br />
        <div id="limitmsg" class="alert alert-danger animate__animated animate__fadeInDown hidden" role="alert">
            {{ __('msg.Youcancompare') }}
        </div>
        <hr />
        <div class="row mt-3 mb-3" id="comparelist">
            
        </div>
    </div>
</div>
<!-- <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script> -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.21.0/moment.min.js" type="text/javascript"></script>
<script src="{{asset('js/bootstrap-datetimepicker.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="{{asset('js/slick.min.js')}}" type="text/javascript"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>



<script type="text/javascript">
 function handleBackFunctionality()
 {
    $('form select').prop('disabled',false);   
    $('form :input').prop('disabled',false); 

 }
    $(document).on('ready', function() {
        $(".items").slick({

            dots: true,
            arrows: false,
            infinite: true,
            speed: 2000,
            slidesToShow: 2,
            slidesToScroll: 2,
            autoplay: true,
            autoplaySpeed: 2000,
            responsive: [{
                    breakpoint: 1024,
                    settings: {
                        arrows: false,
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: true
                    }
                },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
                // You can unslick at a given breakpoint now by adding:
                // settings: "unslick"
                // instead of a settings object
            ]

            //dots: true,
            //infinite: true,
            //slidesToShow: 3,
            //slidesToScroll: 3
        });
    });
</script>
<script>
   $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$('.select2').select2();

$(".city").change(function(){
    var cityid=$(this).val();
    $.ajax({
            url:'{{route('locationlist')}}',
            type:'POST',
            dataType:'json',
            data:{"_token": "{{ csrf_token() }}",cityid:cityid,lang:"<?= app()->getLocale()?>"},
            success: function(response){
                if(response)
                { 
                    $(".locationlist").empty();
                    var optionsAsString = "";
                    $.each(response.locations, function (key, value) {
                    optionsAsString += "<option value='" + value.id + "'>" + value.CommunityName + "</option>";
                    });
                    //$('<option value="">Select Multiple Location</option>').appendTo('.locationlist');
                $('.locationlist').append( optionsAsString );
                $('.locationlist').select2({
                pagination: {more: true}
                });
                

                }
            }

      });
});
<!--- compare property-- !>
@if(session('comparelist') && Request::segment(2)!=="compare")
ShowCompareTab();
@endif()
$(".compare").click(function(){
   const property_no=$(this).data('no');
   $.ajax({
            url:'{{route('setcomparelist')}}',
            type:'POST',
            dataType:'json',
            data:{"_token": "{{ csrf_token() }}",property_no:property_no},
            success: function(response){
                if(response)
                { 
                    ShowCompareTab();
                }
            }

      });
});

function ShowCompareTab()
{   
    $('#comparelist').empty(); 
    $.ajax({
            url:'{{route('showcomparelist')}}',
            type:'get',
            dataType:'json',
            data:{lang:"<?= app()->getLocale()?>"},
            success: function(response){
                if(response)
                { 
                 $('#comparelist').append(response.html);
                 if(response.limitmsg)
                 {
                    $('#limitmsg').removeClass('hidden');   
                 }
                 if(!$('#comparelist').is(':visible'))
                 {
                    $('#compare').css('display','block');
                 }
                 
                  return true;0
                }
            }

      });
}

$("#reset-compare").click(function(){
   $.ajax({
            url:'{{route('removecomparelist')}}',
            type:'delete',
            dataType:'json',
            data:{"_token": "{{ csrf_token() }}"},
            success: function(response){
                if(response)
                { 
                    $('#compare').css('display','none');
                }
            }

      });
});
<!--- compare property-- !>
$(document).on('submit','form',function(){
    $(this).find('select').filter(function(){
 return !$.trim(this.value).length;  
}).prop('disabled',true); 
$(this).find(':input').filter(function(){
 return !$.trim(this.value).length;  
}).prop('disabled',true);
});
</script>
<script type="text/javascript">
    $('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-nav'
    });
    $('.slider-nav').slick({
        slidesToShow: 5,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        arrows: false,
        dots: true,
        centerMode: true,
        focusOnSelect: true
    });
</script>
<script>
    //jQuery for page scrolling feature - requires jQuery Easing plugin
    $(function () {
        $('a.page-scroll').bind('click', function (event) {
            var $anchor = $(this);
            $('html, body').stop().animate({
                scrollTop: $($anchor.attr('href')).offset().top
            }, 1500, 'easeInOutExpo');
            event.preventDefault();
        });
    });
</script>

</body>

</html>
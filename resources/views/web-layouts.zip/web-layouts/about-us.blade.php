@extends('web-layouts.app')
@section('content')
<div class="bread-header" style="background: #ffffff url({{asset('images/about.jpg')}}) center center no-repeat; background-size:cover;">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <h1 class="center font-size-40 font-wt-600">{{ __('msg.AboutUs') }}</h1>
            </div>
        </div>
    </div>
</div>
@if(app()->getLocale() == "ar")
<section class="pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="animate__animated animate__fadeIn animate__slow">
                    <p class="font-size-26 font-wt-600 color-gold">إذا لم تدق الفرصة ، تجد Homes الباب - والمفتاح - لك</p>
                    <p class="font-size-16">
                        هومز هي وكالة عقارية رائدة تدير العقارات السكنية والتجارية في عمان - الأردن. تهدف Homes ، التي يقع مقرها الرئيسي في دبي-الإمارات العربية المتحدة ، إلى تقديم خدمة فريدة لعملائنا في رحلتهم لشراء أو بيع أو تأجير ممتلكاتهم. لدينا مفتاح 
                    </p>                        
                </div>
            </div>
        </div>
    </div>
</section>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-12 center">
        <h1 class="font-size-30 font-wt-600 pull-left animate__animated animate__fadeIn animate__slow">تشمل مجموعة خدماتنا</h1>
    </div>
</div>
<br /><br />
<section class="gray pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 animate__animated animate__fadeIn animate__slow">
                <br /><br /><p class="font-size-24 font-wt-600">وكلاء العقارات المتخصص</p>
                <p class="font-size-16">
                    في هومز ، نتفهم أن لكل عميل متطلبات ملكية فريدة ، لذلك نقوم بتعيين وكيل مخصص لكل نوع من أنواع العقارات. سواء كنت تبحث عن شراء أو بيع أو تأجير عقار أو أرض سكنية أو تجارية ، فلدينا الوكيل المناسب لك.
                </p>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center animate__animated animate__fadeIn animate__slow">
                <img src="{{  asset('images/p6.jpg') }}" width="70%" />
            </div>
        </div>
    </div>
</section>
<section class="pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center animate__animated animate__fadeIn animate__slow">
                <img src="{{  asset('images/p4.jpg') }}" width="70%" />
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 animate__animated animate__fadeIn animate__slow">
                <br /><br /><p class="font-size-24 font-wt-600">تسويق عقاري</p>
                <p class="font-size-16">
                    في هومز ، نتفهم أن لكل عميل متطلبات ملكية فريدة ، لذلك نقوم بتعيين وكيل مخصص لكل نوع من أنواع العقارات. سواء كنت تبحث عن شراء أو بيع أو تأجير عقار أو أرض سكنية أو تجارية ، فلدينا الوكيل المناسب لك.
                </p>
            </div>
        </div>
    </div>
</section>
<section class="gray pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 animate__animated animate__fadeIn animate__slow">
                <br /><br /><p class="font-size-24 font-wt-600">إدارة الأصول</p>
                <p class="font-size-16">
                    إدارة ممتلكات المنازل مخصصة للعملاء الذين يبحثون عن حل شامل لإدارة أصول ممتلكاتهم. من الصيانة إلى إدارة تأجير الأصول ، نحن نعتني بجميع الجوانب المالية والتشغيلية لمحفظتك العقارية.
                </p>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center animate__animated animate__fadeIn animate__slow">
                <img src="{{  asset('images/p5.jpg') }}" width="70%" />
            </div>
        </div>
    </div>
</section>
@else
<section class="pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="animate__animated animate__fadeIn animate__slow">
                    <p class="font-size-26 font-wt-600 color-gold">If opportunity doesn’t knock, Homes finds the door -and the key- for you</p>
                    <p class="font-size-16">
                        Homes is a leading real estate agency managing residential and commercial properties in Amman-Jordan.
                        Headquartered in Dubai-UAE, Homes aims to provide a unique service to our clients in their journey to purchase, sell or lease their property.
                        We have the key to your home.
                    </p>                        
                </div>
            </div>
        </div>
    </div>
</section>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-12 center">
        <h1 class="font-size-30 font-wt-600 pull-left animate__animated animate__fadeIn animate__slow">Our portfolio of services includes</h1>
    </div>
</div>
<br /><br />
<section class="gray pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 animate__animated animate__fadeIn animate__slow">
                <br /><br /><p class="font-size-24 font-wt-600">Specialized real estate agents:</p>
                <p class="font-size-16">
                    At Homes, we understand that each client comes with unique property requirements, so we assign a dedicated agent for each property type. Whether you are looking to buy, sell or lease a residential or commercial property or land, we have the right agent for you.
                </p>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center animate__animated animate__fadeIn animate__slow">
                <img src="{{  asset('images/p6.jpg') }}" width="70%" />
            </div>
        </div>
    </div>
</section>
<section class="pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center animate__animated animate__fadeIn animate__slow">
                <img src="{{  asset('images/p4.jpg') }}" width="70%" />
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 animate__animated animate__fadeIn animate__slow">
                <br /><br /><p class="font-size-24 font-wt-600">Real estate marketing:</p>
                <p class="font-size-16">
                    At Homes, we understand that each client comes with unique property requirements, so we assign a dedicated agent for each property type. Whether you are looking to buy, sell or lease a residential or commercial property or land, we have the right agent for you.
                </p>
            </div>
        </div>
    </div>
</section>
<section class="gray pt-5 pb-5">
    <div class="container">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 animate__animated animate__fadeIn animate__slow">
                <br /><br /><p class="font-size-24 font-wt-600">Asset management:</p>
                <p class="font-size-16">
                    Homes property management is for clients looking for an end-to-end solution to manage their property assets. From maintenance to asset lease management, we take care of all financial and operational aspects of your real estate portfolio.
                </p>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12 center animate__animated animate__fadeIn animate__slow">
                <img src="{{  asset('images/p5.jpg') }}" width="70%" />
            </div>
        </div>
    </div>
</section>



@endif
@if(count($Data->Testimonials) > 0)
<section class="gold-lt">
    <br /><br /><br />
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h2 class="font-size-28 font-wt-600 animate__animated animate__fadeIn animate__slow">{{  __('msg.WhatClientsSay') }}</h2>
            </div>
        </div><br />
        <div class="row items" dir="ltr">
            @foreach ($Data->Testimonials as $val)
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                <div class="card">
                    <div class="card-body">
                        <i class="material-icons icon-8x color-gold">format_quote</i>
                        <p>{{$val->Message  }}</p>
                        <hr>
                        <div class="row">
                            <!--<div class="col-xl-2 col-lg-3 col-md-3 col-sm-3 col-3">
                                <img src="{{ URL::asset('uploads/testimonial/'.$val->Photo) }}" class="roundborder-lg" alt="">
                            </div>-->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <h1 class="font-size-16 font-wt-600">{{$val->CustomerName  }}</h1>
                               <!-- <p class="color-gray">{{$val->Designation  }}</p>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
          
        </div>
    </div>
    <br /><br /><br />
</section>
@endif
<section class="gold">
    <br /><br /><br />
    <div class="container">
        @if(app()->getLocale() == "ar")
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h1 class="font-size-28 font-wt-600 color-white animate__animated animate__fadeIn animate__slow">التق بفريقنا</h1>
                <p class="font-size-16 color-white animate__animated animate__fadeIn animate__slow">محترفون خلف Homes من أجلك</p>
            </div>
        </div><br />
        @else
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                <h1 class="font-size-28 font-wt-600 color-white animate__animated animate__fadeIn animate__slow">Meet Our Team</h1>
                <p class="font-size-16 color-white animate__animated animate__fadeIn animate__slow">Professionals behind Homes for you!!!</p>
            </div>
        </div><br />
        @endif
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                <a href="#">
                    <div class="card center animate__animated animate__fadeIn animate__slow">
                        <div class="card-body">
                            <img src="{{  asset('images/u1.jpg') }}" width="100%" alt="">
                            <br /><br />
                            <h1 class="font-size-16 font-wt-600">Brittany Watkins</h1>
                            <p class="font-wt-500 color-gold">Designation</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                <a href="#">
                    <div class="card center animate__animated animate__fadeIn animate__slow">
                        <div class="card-body">
                            <img src="{{  asset('images/u2.jpg') }}" width="100%" alt="">
                            <br /><br />
                            <h1 class="font-size-16 font-wt-600">Brittany Watkins</h1>
                            <p class="font-wt-500 color-gold">Designation</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                <a href="#">
                    <div class="card center animate__animated animate__fadeIn animate__slow">
                        <div class="card-body">
                            <img src="{{  asset('images/u3.jpg') }}" width="100%" alt="">
                            <br /><br />
                            <h1 class="font-size-16 font-wt-600">Brittany Watkins</h1>
                            <p class="font-wt-500 color-gold">Designation</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                <a href="#">
                    <div class="card center animate__animated animate__fadeIn animate__slow">
                        <div class="card-body">
                            <img src="{{  asset('images/u2.jpg') }}" width="100%" alt="">
                            <br /><br />
                            <h1 class="font-size-16 font-wt-600">Brittany Watkins</h1>
                            <p class="font-wt-500 color-gold">Designation</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <br /><br /><br />
</section>

@endsection()
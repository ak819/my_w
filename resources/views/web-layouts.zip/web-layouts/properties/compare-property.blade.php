@extends('web-layouts.app')
@section('content')
<section class="white pt-5 pb-5">
    <div class="container-fluid">
        <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 center">
                    <h1 class="float-start font-size-26 font-wt-600">Compare Properties</h1>
                    <a href="{{ URL::previous() }}" class="btn btn-gold btn-medium float-end">Back</a>
                </div>
            </div>
        <div class="table-responsive animate__animated animate__fadeIn animate__slow">
            <table width="100%" cellspacing="0" cellpadding="0" class="table">
                <tbody>
                    <tr>
                        <td width="15%" class="pe-0">
                            <ul class="list-group">
                                <li class="list-group-item height-180">
                                </li>
                                <li class="list-group-item">{{ __('msg.ReferenceNo') }}</li>
                                <li class="list-group-item">{{ __('msg.City') }}</li>
                                <li class="list-group-item">{{ __('msg.Location') }}</li>
                                <li class="list-group-item">{{ __('msg.BuiltupArea') }} (Sq m.)</li>
                                <li class="list-group-item">{{ __('msg.Bedrooms') }}</li>
                                <li class="list-group-item">{{ __('msg.Bathrooms') }}</li>
                                <li class="list-group-item">{{ __('msg.Furnished') }}</li>
                                {{-- <li class="list-group-item">Parking</li> --}}
                                <li class="list-group-item">{{ __('msg.Swimming Pool') }}</li>
                                <li class="list-group-item">{{ __('msg.Apartment Type') }}</li>
                                <li class="list-group-item">{{ __('msg.Outdoor Area') }}</li>
                                <li class="list-group-item">{{ __('msg.Number of Floors') }}</li>
                                <li class="list-group-item">{{ __('msg.PlotArea') }} (Sq m.)</li>
                                <li class="list-group-item">{{ __('msg.Villa Type') }}</li>
                                <li class="list-group-item">{{ __('msg.Fitted') }}</li>
                                <li class="list-group-item">{{ __('msg.Rented') }}</li>
                                <li class="list-group-item">{{ __('msg.Floor Number') }}</li>
                                <li class="list-group-item">{{ __('msg.Number of Streets') }}</li>
                                <li class="list-group-item">{{ __('msg.Serviced') }}</li>
                                <li class="list-group-item">{{ __('msg.Commercial Type') }}</li>
                                <li class="list-group-item">{{ __('msg.Building Percentage Number') }}</li>
                                <li class="list-group-item">{{ __('msg.Facade Number') }}</li>
                                <li class="list-group-item">{{ __('msg.Residential Land Type') }}</li>
                                <li class="list-group-item">{{ __('msg.Building Facade Type') }}</li>
                            </ul>
                        </td>
                        @if($Data->first())
                         @foreach ($Data as $val)
                         @if(app()->getLocale()=="en")
                                <td class="ps-0 pe-0 pt-0">
                                    <ul class="list-group">
                                        <li class="list-group-item height-180 center">
                                            @if ($val->FileName)
                                            <img src="{{ asset("uploads/properties/orignal/".$val->PropertyRefNo."/".$val->FileName) }}" width="30%"  alt="{{ $val->ImgAlt }}">
                                            <div class="list-overlay"></div>  
                                            @else
                                            <img src="{{ asset('images/noimg.jpg')}}" width="30%" alt="no image">
                                            @endif
                                            <br />
                                            <p class="font-size-12 font-wt-500 mt-2 mb-2">{{ Str::limit(trim(preg_replace('/\s\s+/', ' ', $val->PropertyTitle)),70, $end='...')}}</p>
                                            <p class="font-size-16 font-wt-600 mb-0 color-gold">{{ currency_format($val->Price) }} </p>
                                        </li>
                                        <li class="list-group-item">{{  config('constants.AdTypeshort.'.$val->AdType)}}-{{   preg_replace('/[^0-9]/', '', $val->PropertyRefNo);   }}</li>
                                        <li class="list-group-item"> {{ $val->CityName }}</li>
                                        <li class="list-group-item"> {{ ($val->CommunityName)? $val->CommunityName : "-"}}</li>
                                        <li class="list-group-item">{{ ($val->UnitBuiltupArea)? $val->UnitBuiltupArea : "-" }} </li>
                                        <li class="list-group-item">{{ ($val->NoBedrooms)? $val->NoBedrooms  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->NoBathrooms)? $val->NoBathrooms  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->Furnished)? "Yes"  :  "No" }}</li>
                                        {{-- <li class="list-group-item">{{ ($val->Parking)? $val->Parking  :  "No" }}</li> --}}
                                        <li class="list-group-item">{{ ($val->SwimmingPool)? "Yes"  :  "No" }}</li>
                                        <li class="list-group-item">{{ ($val->ApartmentType)? $val->ApartmentType  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->OutdoorArea)? "Yes"  :  "No" }}</li>
                                        <li class="list-group-item">{{ ($val->NoFloors)? $val->NoFloors  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->PlotSize)? $val->PlotSize :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->VillaType)? $val->VillaType  :  "-" }}</li>
                                        <li class="list-group-item">{{"-"}}</li>
                                        <li class="list-group-item">{{ ($val->Rented)? "Yes"  :  "No" }}</li>
                                        <li class="list-group-item">{{ ($val->FloorNumber)? $val->FloorNumber  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->Nostreets)? $val->Nostreets  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->Serviced)? "Yes"  :  "No" }}</li>
                                        <li class="list-group-item">{{ ($val->CommercialType)? $val->CommercialType  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->BuildPercentageNumber)? $val->BuildPercentageNumber  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->FacadeNumber)? $val->FacadeNumber  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->ResidentialLandType)? $val->ResidentialLandType  :  "-" }}</li>
                                        <li class="list-group-item">{{ ($val->BuildFacadeType)? $val->BuildFacadeType  :  "-" }}</li>
                                    </ul>
                                </td>
                            @else
                            <td class="ps-0 pe-0">
                                <ul class="list-group">
                                    <li class="list-group-item height-180 center">
                                        @if ($val->FileName)
                                        <img src="{{ asset("uploads/properties/orignal/".$val->PropertyRefNo."/".$val->FileName) }}" alt="{{ $val->ImgAlt }}">
                                        <div class="list-overlay"></div>  
                                        @else
                                        <img src="{{ asset('images/noimg.jpg')}}" width="30%" alt="">
                                        @endif
                                        <br />
                                        <p class="font-size-12 font-wt-500 mt-2 mb-2">{{ Str::limit(trim(preg_replace('/\s\s+/', ' ', $val->PropertyTitle)),70, $end='...')}}</p>
                                        <p class="font-size-16 font-wt-600 mb-0 color-gold">{{ currency_format($val->Price) }} </p>
                                    </li>
                                    <li class="list-group-item">{{  config('constants.AdTypeshort.'.$val->AdType)}}-{{   preg_replace('/[^0-9]/', '', $val->PropertyRefNo);   }}</li>
                                    <li class="list-group-item"> {{ $val->CityName }}</li>
                                    <li class="list-group-item"> {{ ($val->CommunityName)? $val->CommunityName : "-"}}</li>
                                    <li class="list-group-item">{{ ($val->UnitBuiltupArea)? $val->UnitBuiltupArea : "-" }} </li>
                                    <li class="list-group-item">{{ ($val->NoBedrooms)? $val->NoBedrooms  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->NoBathrooms)? $val->NoBathrooms  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->Furnished)? config('constants.YesNoAr.Yes')  :   config('constants.YesNoAr.No') }}</li>
                                    {{-- <li class="list-group-item">{{ ($val->Parking)? $val->Parking  :  "No" }}</li> --}}
                                    <li class="list-group-item">{{ ($val->SwimmingPool)? config('constants.YesNoAr.Yes')  :  config('constants.YesNoAr.No') }}</li>
                                    <li class="list-group-item">{{ ($val->ApartmentType)? config('constants.ApartmentTypeAr.'.$val->ApartmentType)  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->OutdoorArea)? config('constants.YesNoAr.Yes')  :   config('constants.YesNoAr.No') }}</li>
                                    <li class="list-group-item">{{ ($val->NoFloors)? $val->NoFloors  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->PlotSize)? $val->PlotSize :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->VillaType)? config('constants.VillaTypeAr.'.$val->VillaType)  :  "-" }}</li>
                                    <li class="list-group-item">{{"-"}}</li>
                                    <li class="list-group-item">{{ ($val->Rented)? config('constants.YesNoAr.Yes')  :   config('constants.YesNoAr.No') }}</li>
                                    <li class="list-group-item">{{ ($val->FloorNumber)? $val->FloorNumber  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->Nostreets)? $val->Nostreets  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->Serviced)? config('constants.YesNoAr.Yes')  :   config('constants.YesNoAr.No') }}</li>
                                    <li class="list-group-item">{{ ($val->CommercialType)?  config('constants.CommercialTypeAr.'.$val->CommercialType)  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->BuildPercentageNumber)? $val->BuildPercentageNumber  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->FacadeNumber)? $val->FacadeNumber  :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->ResidentialLandType)?  config('constants.ResidentialLandTypeAr.'.$val->ResidentialLandType) :  "-" }}</li>
                                    <li class="list-group-item">{{ ($val->BuildFacadeType)? config('constants.BuildingFacadeTypeAr.'.$val->BuildFacadeType)  :  "-" }}</li>
                                </ul>
                            </td>
                            @endif
                         @endforeach
                        @else
                        <h1 class="font-size-28 font-wt-600 animate__animated animate__fadeIn animate__slow">No properties available to compare</h1>
                        @endif
                    </tr>                     
                </tbody>
            </table>
        </div>
    </div>
</section>    
</section>    
@endsection
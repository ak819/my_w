@extends('web-layouts.app')
@section('content')
<section class="gray">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                <div class="commonbox animate__animated animate__fadeIn animate__slow">
                    <div class="row">
                        <div class="col-xl-9 col-lg-9 col-md-8 col-sm-8 col-12">
                            <h1 class="font-size-18 font-wt-600 lh-25 mb-1">{{ $Data->PropertyTitle }}</h1>
                            <p class="mb-1"><i class="material-icons icon-1x">location_on</i> {{ $Data->CommunityName }},  {{ $Data->CityName }}, {{ __('msg.Jordan') }}</p>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-12">
                            <h1 class="font-size-24 lh-25 color-gold font-wt-700 float-end"> {{ currency_format($Data->Price) }}</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <!--<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-12">
            </div>-->
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-12">
                @if($Data->Images->first() && $Data->Images->count() > 1)
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="commonbox animate__animated animate__fadeIn animate__slow">
                            
                            <div class="slider-for">
                                @foreach ($Data->Images as $img)
                                <div class="item"><img src="{{ asset("uploads/properties/orignal/".$Data->PropertyRefNo."/".$img->FileName) }}" width="100%"  alt="{{ $img->ImgAlt }}"/></div>
                                @endforeach
                               
                            </div>
                            <div class="slider-nav">
                                @foreach ($Data->Thumbs as $img)
                                <div class="item"><img src="{{ asset("uploads/properties/thumb/".$Data->PropertyRefNo."/".$img->FileName) }}" width="100%"  alt="{{ $img->ImgAlt }}"/></div>
                                @endforeach
                            </div>
                            
                        </div>
                    </div>
                </div>
                @elseif($Data->Images->first() && $Data->Images->count() == 1)
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="commonbox animate__animated animate__fadeIn animate__slow">
                            <div class="slider-for">
                                @foreach ($Data->Images as $img)
                                <div class="item"><img src="{{ asset("uploads/properties/orignal/".$Data->PropertyRefNo."/".$img->FileName) }}" width="100%"  alt="{{ $img->ImgAlt }}"/></div>
                                @endforeach
                               
                            </div>
                        </div>
                    </div>
                </div>
                @endif
                <br />
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <nav class="navbar navbar-property navbar-expand-lg pt-0 pb-0 black stickymenu">
                            <button class="navbar-toggler btn btn-outline-gold btn-small" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                                <i class="material-icons">
                                    more_vert
                                </i>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                                <ul class="navbar-nav ms-0 mt-2 mt-lg-0">
                                    <li class="hidden">
                                        <a class="page-scroll" href="#page-top"></a>
                                    </li>
                                    <li>
                                        <a class="page-scroll" href="#description"><i class="icon-note"></i>{{  __('msg.Description') }}</a>
                                    </li>
                                    <li>
                                        <a class="page-scroll" href="#features"><i class="icon-rocket"></i>{{  __('msg.Features') }}</a>
                                    </li>
                                    {{-- <li>
                                        <a class="page-scroll" href="#info"><i class="icon-trophy"></i> Additional Info</a>
                                    </li> --}}
                                    <li>
                                        <a class="page-scroll" href="#videos"><i class="icon-social-youtube"></i>{{  __('msg.Videos') }}</a>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                        <br />
                        <section id="description" class="commonbox animate__animated animate__fadeIn animate__slow">
                            <h3 class="font-size-16 font-wt-600"><!--<i class="material-icons icon-1x1">description</i>-->{{  __('msg.Description') }}</h3>
                            <hr />
                            {!! $Data->Description !!}
                        </section>
                        <section id="features" class="commonbox animate__animated animate__fadeIn animate__slow">
                            <h3 class="font-size-16 font-wt-600"><!--<i class="material-icons icon-1x1">description</i>-->{{  __('msg.Features') }}</h3>
                            <hr />
                            <div class="row">
                                @if($Data->UnitBuiltupArea > 0)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.BuiltupArea') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->UnitBuiltupArea }} Sq m.</p>
                                </div>
                                @endif
                                @if($Data->PlotSize > 0)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.PlotArea') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->PlotSize }} Sq m.</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->Furnished)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Furnished') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>Yes</p>
                                </div>
                                @endif
                                @if($Data->Parking)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">Parking:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->Parking }}</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->NoFloors)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Number of Floors') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->NoFloors }}</p>
                                </div>
                                @endif
                                @if($Data->NoFloors)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Floor Number') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->FloorNumber }}</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->ApartmentType)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Apartment') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->ApartmentType }}</p>
                                </div>
                                @endif
                                @if($Data->VillaType)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Villa Type') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->VillaType }}</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->CommercialType)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Commercial Type') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->CommercialType }}</p>
                                </div>
                                @endif
                                @if($Data->ResidentialLandType)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Residential Land Type') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ $Data->ResidentialLandType }}</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->SwimmingPool)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Swimming Pool') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>Yes</p>
                                </div>
                                @endif
                                @if($Data->OutdoorArea)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Outdoor Area') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>Yes</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->Rented)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Rented') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>No</p>
                                </div>
                                @endif
                                @if($Data->Nostreets)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Number of Streets') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{  $Data->Nostreets }}</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->Serviced)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Serviced') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>Yes</p>
                                </div>
                                @endif
                                @if($Data->BuildPercentageNumber)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Building Percentage Number') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ 	$Data->BuildPercentageNumber }} %</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->FacadeNumber)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Facade Number') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ 	$Data->FacadeNumber }}</p>
                                </div>
                                @endif
                                @if($Data->FacadeNumber)
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p class="font-wt-600">{{  __('msg.Building Facade Type') }}:</p>
                                </div>
                                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 col-6">
                                    <p>{{ 	$Data->BuildFacadeType }}</p>
                                </div>
                                @endif
                            </div>                                
                        </section>
                        {{-- <section id="info" class="commonbox animate__animated animate__fadeIn animate__slow">
                            <h3 class="font-size-16 font-wt-600"><!--<i class="material-icons icon-1x1">description</i>-->Information</h3>
                            <hr />
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <p class="lh-25">
                                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.<br /><br />
                                        Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.
                                    </p>
                                </div>
                            </div>
                        </section> --}}
                        <section id="videos" class="commonbox animate__animated animate__fadeIn animate__slow">
                            <h3 class="font-size-16 font-wt-600"><!--<i class="material-icons icon-1x1">description</i>-->{{  __('msg.Videos') }}</h3>
                            <hr />
                            <div class="row">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    @if ($Data->Video)
                                    <iframe width="100%" height="420" src="{{ $Data->Video  }}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> 
                                    @else
                                        <h5>{{  __('msg.NoVideo') }}</h5>
                                    @endif
                                   
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="commonbox sticky-top animate__animated animate__fadeIn animate__slow">
                           
                            <div class="row">
                                @if($Data->ApartmentType)
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 center">
                                    <span class="font-wt-600">{{  __('msg.Apartment') }}</span><br />
                                    <p>{{ $Data->ApartmentType }}</p>
                                </div>
                                @endif
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 center">
                                    <span class="font-wt-600">{{  __('msg.PropertyID') }}</span><br />
                                    <p>{{  config('constants.AdTypeshort.'.$Data->AdType)}}-{{   preg_replace('/[^0-9]/', '', $Data->PropertyRefNo);   }}</p>
                                </div>
                            </div>
                            <div class="row">
                                @if($Data->NoBedrooms)
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 center">
                                    <i class="material-icons icon-3x color-gold">king_bed</i>
                                    <p><span class="font-wt-600">{{ $Data->NoBedrooms }} </span>{{  __('msg.Bedrooms') }}</p>
                                </div>
                                @endif
                                @if($Data->NoBathrooms)
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 center">
                                    <i class="material-icons icon-3x color-gold">shower</i>
                                    <p><span class="font-wt-600">{{ $Data->NoBathrooms }} </span>{{  __('msg.Bathrooms') }}</p>
                                </div>
                                @endif
                            </div>
                            <div class="row">
                                @if($Data->UnitBuiltupArea > 0 )
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 center">
                                    <i class="material-icons icon-3x color-gold">aspect_ratio</i>
                                    <p><span class="font-wt-600">{{ $Data->UnitBuiltupArea }}</span> Sq m.</p>
                                </div>
                                @endif
                                @if($Data->PlotSize > 0 )
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 center">
                                    <i class="material-icons icon-3x color-gold">aspect_ratio</i>
                                    @if($Data->PlotSize > 0)
                                    <p><span class="font-wt-600">{{ $Data->PlotSize }}</span> Sq m.</p>
                                    @endif
                                </div>
                                @endif
                            </div>
                            <br/>
                             <h1 class="font-size-16 lh-25 font-wt-600 text-center">{{  __('msg.InterestedIn') }}</h1>
                            <hr />
                            <div class="center">
                            <a  href="#requestInfo"  class="btn btn-gold btn-medium w-100 page-scroll">{{  __('msg.RequestInfo') }}</a><br/><br/>
                            <a href="https://wa.me/{{trim($Data->DisplayPhone)}}?text=Hello Homes! I would like to enquire about your services." title="WhatsApp" class="btn btn-outline-black btn-medium w-100"><i class="material-icons icon-2x1">whatsapp</i>WhatsApp</a>
                            </div>
                            <br/>
                            <div class="center">
                                <h1 class="font-size-16 font-wt-600">{{  __('msg.Or') }}</h1>
                                <p class="font-size-16 font-wt-600">{{  __('msg.ContactUsTime') }}</p>
                                 @if($Data->DisplayPhoto)
                                 <img src="{{  URL::asset('uploads/agent/'.$Data->DisplayPhoto)  }}" class="img-round-border mb-3"/>
                                 @endif
                                 @if($Data->DisplayName)
                                <h1 class="font-size-16 lh-25 font-wt-600">{{ $Data->DisplayName }}</h1>
                                @endif
                                @if($Data->DisplayPhone)
                                <a href="tel:{{ $Data->DisplayPhone }}"><p class="mb-1"><i class="material-icons icon-1x">{{  __('msg.call') }}</i>&nbsp;{{ $Data->DisplayPhone }}</p></a>
                                @endif
                                @if($Data->DisplayEmail)
                                <a href="mailto:{{ $Data->DisplayEmail }}"><p><i class="material-icons icon-1x">{{  __('msg.email') }}</i>&nbsp;{{ $Data->DisplayEmail }}</p></a>
                                @endif
                            </div>
                            
                            
                            
                        </div>
                       
                    </div>
                </div>
            </div><br />
            
        </div>
        <div class="row" id="requestInfo">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="commonbox animate__animated animate__fadeIn animate__slow">
                    @if($message = Session::get('success'))
                    <div class="alert alert-success animate__animated animate__fadeInDown" role="alert">
                        <strong>{{ $message }}</strong>
                    </div>
                    @endif
                    @if($message = Session::get('error'))
                    <div class="alert alert-danger animate__animated animate__fadeInDown"  role="alert">
                         <strong>{{  $message  }}</strong> .
                    </div>
                    @endif
                    <h1 class="font-size-18 font-wt-600">{{  __('msg.InquireProperty') }}</h1>
                    <hr />
                    <form action="{{ route('rquestInfo') }}" method="Post">
                        @csrf
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                            <input type="text" class="form-control" name="Name" value="{{old('Name')}}" placeholder="{{ __('msg.YourName') }}" required/>
                            @error('Name')
                            <span class="error">{{ $message }}</span>
                               @enderror
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                            <input type="text" class="form-control"  name="Phone" value="{{old('Phone')}}"  placeholder="{{ __('msg.YourMobile') }}"  pattern="\d{10}" maxlength="10" required/>
                            @error('Phone')
                            <span class="error">{{ $message }}</span>
                               @enderror
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                            <input type="email" class="form-control"  name="Email" value="{{old('Email')}}" placeholder="{{ __('msg.YourEmailId') }}" required/>
                            @error('Email')
                            <span class="error">{{ $message }}</span>
                               @enderror
                        </div>
                        <input type="hidden" name="PropertyID" value="{{ $Data->Guid }}"><br> 
                    </div>
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <textarea class="form-control" name="Message" placeholder="{{ __('msg.YourMessage') }}" required>{{old('Message')}}</textarea>
                            @error('Message')
                            <span class="error">{{ $message }}</span>
                               @enderror
                            <button type="submit" class="btn btn-gold btn-medium float-end">{{  __('msg.RequestInfo') }}</button>
                        </div>
                    </div>
                  </form>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
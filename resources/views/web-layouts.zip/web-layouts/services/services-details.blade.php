@extends('web-layouts.app')
@section('content')

<img src="{{ asset('images/service.jpg')}}" width="100%" />    
<section class="gray">
    <div class="container">
        

        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 center">
                <h1 class="font-size-28 font-wt-600 animate__animated animate__fadeIn animate__slow">{{$item->Title}}</h1>
            </div>
        </div>
        <br />
        <div class="row">
            <!--<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-12">
            </div>-->
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-12">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="commonbox animate__animated animate__fadeIn animate__slow">
                            <img src="{{ asset('uploads/services/'.$item->Image) }}" width="100%" />
                            <br /><br />

                            {!! $item->Description !!}
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="commonbox sticky-top animate__animated animate__fadeIn animate__slow">
                            <h1 class="font-size-16 lh-25 font-wt-600 text-center">Interested in this service?</h1>
                            <hr />
                            <div class="text-center">
                                <a href="" class="btn btn-gold btn-medium w-100">{{ __('msg.RequestInfo') }}</a>
                                <br /><br />
                                <a href="https://wa.me/{{trim('+962792222140')}}?text=Hello Homes! I would like to enquire about your services." title="WhatsApp" class="btn btn-outline-black btn-medium w-100"><i class="material-icons icon-2x1">whatsapp</i>WhatsApp</a>
                            </div>
                            <br />
                            @php
                            if(app()->getLocale() == "ar")
                            {
                                $contactinfo=App\Models\ContactInfo::first(['Email','Phone','AddressAr AS Address']);
                            }else{
                                $contactinfo=App\Models\ContactInfo::first(['Email','Phone','Address']);
                            }
                            @endphp
                            <div class="center">
                                <h1 class="font-size-16 font-wt-600">{{  __('msg.Or') }}</h1>
                                <p class="font-size-16 font-wt-600">{{  __('msg.ContactUsTime') }}</p>
                                <img src="{{asset('images/logo.png')}}" width="60%"/>
                                {{-- <h1 class="font-size-16 lh-25 font-wt-600">Agent Name</h1> --}}
                                <a href="tel:{{ $contactinfo->Phone  }}"><p class="mb-1"><i class="material-icons icon-1x">call</i>&nbsp;{{ $contactinfo->Phone  }}</p></a>
                               <a href="mailto:{{ $contactinfo->Email }}"><p><i class="material-icons icon-1x">email</i>&nbsp;{{ $contactinfo->Email  }}</p></a>
                            </div>



                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="commonbox animate__animated animate__fadeIn animate__slow">
                    @if($message = Session::get('success'))
                    <div class="alert alert-success animate__animated animate__fadeInDown" role="alert">
                        <strong>{{ $message }}</strong>
                    </div>
                    @endif
                    @if($message = Session::get('error'))
                    <div class="alert alert-danger animate__animated animate__fadeInDown"  role="alert">
                         <strong>{{  $message  }}</strong> .
                    </div>
                    @endif
                    <h1 class="font-size-18 font-wt-600">Inquire about this service</h1>
                    <hr />
                    <form action="{{ route('service-rquestInfo') }}" method="Post">
                        @csrf
                    <div class="row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                            <input type="text" name="Name" class="form-control" placeholder="{{ __('msg.YourName') }}" />
                            @error('Name')
                            <span class="error">{{ $message }}</span>
                               @enderror
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                            <input type="text"  name="Phone" class="form-control" placeholder="{{ __('msg.YourMobile') }}" />
                            @error('Phone')
                            <span class="error">{{ $message }}</span>
                               @enderror
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-6">
                            <input type="text"   name="Email" class="form-control" placeholder="{{ __('msg.YourEmailId') }}" />
                            @error('Email')
                            <span class="error">{{ $message }}</span>
                               @enderror
                        </div>
                        <input type="hidden" name="ServiceID" value="{{ $item->Guid }}"><br>
                    </div>
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <textarea name="Message" class="form-control" placeholder="{{ __('msg.YourMessage') }}"></textarea>
                            @error('Message')
                            <span class="error">{{ $message }}</span>
                               @enderror
                            <button type="submit" class="btn btn-gold btn-medium float-right">{{  __('msg.RequestInfo') }}</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection()
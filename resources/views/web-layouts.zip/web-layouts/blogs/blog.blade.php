@extends('web-layouts.app')
@section('content')
<section class="gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-10 col-sm-10 col-12">
                    <h1 class="font-size-22 font-wt-600 animate__animated animate__fadeIn animate__slow">Blog</h1>
                </div>
            </div><br />
            @foreach ($items as $item)
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
               
                    <div class="row">
                   

                        <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-xs-12">
                            <div class="card animate__animated animate__fadeIn animate__slow">
                                <figure>
                                    <a href="{{ route('blogdetails',$item->Guid)}}">
                                        <img src="{{ URL::asset('uploads/blog/'.$item->Image) }}" class="card-img-top listing-card-img" alt="">
                                        <div class="list-overlay"></div>
                                    </a>
                                </figure>
                                <div class="card-body">
                                    <a href="{{ route('blogdetails',$item->Guid)}}">
                                        <h1 class="font-size-16 font-wt-600">{!! Str::limit(strip_tags($item->Title),100, $end='.......')  !!}</h1>
                                    </a>
                                    <p class="font-size-12 font-wt-500 color-gray">{!! Str::limit(strip_tags($item->Description),100, $end='.......')  !!}</p>                                    
                                    <p class="font-size-14 font-wt-500 color-gold float-left mb-1">{{date('d-M-Y H:i:s', strtotime($item->CreatedDate))}}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </section>
@endsection()
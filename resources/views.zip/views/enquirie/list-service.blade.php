@extends('admin-layouts.app')
@section('title','Service-Enquiries')
@section('content')
            <div class="content-inner">
                <div class="bc-box">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="float-left mt-2">
                                <div class="d-inline-flex align-items-center">
                                    <h1>Service Enquiries</h1><span class="font-size-16 font-wt-600 color-gray">{{ count($enquiries) }} Total</span>
                                    <ol class="bclink">
                                        <li class="breadcrumb-item">
                                             <a href="{{ route('admin') }}"><i class="bx bx-home-alt font-size-18 color-gold"></i></a>
                                        </li>
                                        <li class="breadcrumb-item active" aria-current="page">All Listing</li>
                                    </ol>
                                </div>
                            </div>
                            <!--<div class="float-right">
                                <a href="" class="btn btn-medium btn-gold ml-2 mr-2 float-right">Add</a>
                            </div>-->
                        </div>
                    </div>
                </div>
                 @if(count($enquiries) < 1) 
                <section class="commonbox center">
                    <div class="panel-body">
                        <i class="material-icons color-gray icon-7x">contact_phone</i><br><br>
                        <h3 class="font-size-18 font-wt-600">No enquiries available.</h3><br>
                    </div>
                </section>
                 @endif
        @if(count($enquiries) >=1) 
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="table-responsive animate__animated animate__fadeIn animate__slow">
                            @if ($message = Session::get('success'))

                            <div class="alert alert-success animate__animated animate__fadeInDown" role="alert">
                
                                    <strong>{{ $message }}</strong>
                            </div>
                                 @endif
                                 @if (count($errors) > 0)
                                 <div class="alert alert-danger animate__animated animate__fadeInDown"  role="alert">
                                     <strong>Error</strong> An error occured while saving note.
                                 
                                 </div>
                                  @endif
                            <table width="100%" cellspacing="0" cellpadding="0" class="table" id="ExportDatatable">
                                <thead>
                                <tr>     
                                        <th class="show_excel">Service</th>
                                        <th class="show_excel">Name</th>
                                        <th class="show_excel">Mobile No</th>
                                        <th class="show_excel">Email Id</th>
                                        <th class="show_excel" >Message</th>
                                        <th class="show_excel">Created</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     @foreach ($enquiries as $enquirie)
                                    <tr>
                                        <td>{{$enquirie->Service}}</td>
                                        <td>{{$enquirie->Name}}</td>
                                        <td>{{$enquirie->Mobile}}</td>
                                        <td>{{$enquirie->Email}}</td>
                                        <td>{{$enquirie->Message}}</td>
                                        <td><span style="display:none;">{{ strtotime($enquirie->CreatedDate) }}</span>{{ datetime_format($enquirie->CreatedDate)}}</td>
                                    </tr>
                                     @endforeach
                                    
                                </tbody>
                            </table>
                        </div>
                      
                    </div>
                </div>
                @endif
            </div>
           
      @endsection()
@extends('web-layouts.app')
@section('content')
@section('title'){{ $item->MetaTitle }} @endsection
<div class="bread-header" style="background: #ffffff url({{asset('uploads/herobanner/'.$item->hero_banner)}}) center center no-repeat; background-size:cover;">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1 class="center font-size-40 font-wt-600"> {{ __('msg.Blog') }} </h1>
                </div>
            </div>
        </div>
    </div>
<section class="gray">
        <div class="container">
          
            <div class="row">
                <div class="col-xl-8 col-lg-7 col-md-7 col-sm-7 col-12">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="commonbox animate__animated animate__fadeIn animate__slow">
                                <img src="{{ URL::asset('uploads/blog/'.$item->Image) }}" alt="{{ $item->Alt  }}" width="100%" />
                                <br /><br /><br />
                                <h1 class="font-size-20 font-wt-600 mb-1">{{$item->Title}}</h1>
                                <p><!--{{ __('msg.Postedon') }}:--><span dir="ltr"> {{date('d-M-Y', strtotime($item->CreatedDate))}}</span></p>
                                <br />
                                <div class="row">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    {!! $item->Description  !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-12">
                 <div class="row">
               
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                       
                            <div class="commonbox animate__animated animate__fadeIn animate__slow">
                                <h1 class="font-size-18 font-wt-600">{{ __('msg.OtherPosts') }}</h1>
                                <hr />
                                @if (count($blogLimits) > 0)
                                @foreach ($blogLimits as $bloglimit)
                                <div class="row mb-4">
                                     <div class="col-xl-4 col-lg-4 col-md-12 col-sm-4 col-6">
                                         <a href="{{ route('blogdetails',[app()->getLocale(),preg_replace("/[^A-Za-z0-9\-]/", '-', $bloglimit->LinkTitle),$bloglimit->Guid])}}"><img src="{{ URL::asset('uploads/blog/'.$bloglimit->Image) }}"  alt="{{ $bloglimit->Alt  }}" width="100%" /></a>
                                     </div>
                                     <div class="col-xl-8 col-lg-8 col-md-12 col-sm-8 col-6">
                                         <a href="{{ route('blogdetails',[app()->getLocale(),preg_replace("/[^A-Za-z0-9\-]/", '-', $bloglimit->LinkTitle),$bloglimit->Guid])}}"><p class="font-size-14 font-wt-600 mb-1">{{ $bloglimit->Title }} </p></a>
                                         <p class="font-size-12 font-wt-500 mb-1"><!-- {{ __('msg.Postedon') }}:--> <span dir="ltr"> {{date('d-M-Y', strtotime($bloglimit->CreatedDate))}}</span></p>
                                     </div>
                                 </div>
                                 @endforeach
                                @else
                                    <span>{{ __('msg.CommingSoon') }}</span>
                                @endif
                               
                            </div>
                        
                            <div style="height:580px;"></div>
                        </div>
                       
                    </div>
                    
                </div><br />
              
            </div>
        </div>
    </section>
    @endsection()
<ul class="list-unstyled components">
    <li class="nav-item active"><a href="{{ route('admin') }}" class="nav-link"><i class="material-icons font-size-20 color-gold">dashboard</i>&nbsp;&nbsp;<span>Dashboard</span></a></li>
    <li class="nav-item"><a href="{{ route('service.index')}}" class="nav-link"><i class="material-icons font-size-20 color-gold">design_services</i>&nbsp;&nbsp;<span>Services</span></a></li>
    <li class="nav-item"><a href="{{ route('testimonial.index')}}" class="nav-link"><i class="material-icons font-size-20 color-gold">contact_mail</i>&nbsp;&nbsp;<span>Testimonials</span></a></li>
    <li class="nav-item"><a href="{{ route('agent.index')}}" class="nav-link"><i class="material-icons font-size-20 color-gold">people</i>&nbsp;&nbsp;<span>Agents</span></a></li>
    <li class="nav-item"><a href="{{ route('blog.index')}}" class="nav-link"><i class="material-icons font-size-20 color-gold">rss_feed</i>&nbsp;&nbsp;<span>Blogs</span></a></li>
    <li class="nav-item"><a href="{{ route('banner.index')}}" class="nav-link"><i class="material-icons font-size-20 color-gold">collections</i>&nbsp;&nbsp;<span>Banners</span></a></li>
   
   
     
   
</ul>
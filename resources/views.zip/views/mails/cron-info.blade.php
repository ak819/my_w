<!DOCTYPE html>
<html>
<head>
    <title>Homes Jordan</title>
</head>
<body>
    <h1></h1>
    <p>{{ $data['msg'] }}</p>
   
    <p>Thank you</p>
</body>
</html>